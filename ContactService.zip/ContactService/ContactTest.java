import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    void validContactCreatesSuccessfully() {
        Contact c = new Contact("123", "John", "Doe", "0123456789", "123 Main St");
        assertEquals("123", c.getContactId());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("0123456789", c.getPhone());
        assertEquals("123 Main St", c.getAddress());
    }

    @Test
    void contactIdMustBeNonNullAndMax10Chars() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact(null, "John", "Doe", "0123456789", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("12345678901", "John", "Doe", "0123456789", "123 Main St"));
    }

    @Test
    void firstNameMustBeNonNullAndMax10Chars() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("1", null, "Doe", "0123456789", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("1", "ThisNameIsTooLong", "Doe", "0123456789", "123 Main St"));
    }

    @Test
    void lastNameMustBeNonNullAndMax10Chars() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("1", "John", null, "0123456789", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("1", "John", "ThisNameIsTooLong", "0123456789", "123 Main St"));
    }

    @Test
    void phoneMustBeExactly10Digits() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("1", "John", "Doe", null, "123 Main St"));
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("1", "John", "Doe", "12345", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("1", "John", "Doe", "ABCDEFGHIJ", "123 Main St"));
    }

    @Test
    void addressMustBeNonNullAndMax30Chars() {
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("1", "John", "Doe", "0123456789", null));
        String longAddress = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456"; // 32 chars
        assertTrue(longAddress.length() > 30);
        assertThrows(IllegalArgumentException.class,
            () -> new Contact("1", "John", "Doe", "0123456789", longAddress));
    }

    @Test
    void settersEnforceSameValidation() {
        Contact c = new Contact("1", "John", "Doe", "0123456789", "123 Main St");

        // valid updates
        c.setFirstName("Jane");
        assertEquals("Jane", c.getFirstName());
        c.setLastName("Smith");
        assertEquals("Smith", c.getLastName());
        c.setPhone("9876543210");
        assertEquals("9876543210", c.getPhone());
        c.setAddress("456 Elm Rd");
        assertEquals("456 Elm Rd", c.getAddress());

        // invalid updates
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName("TooLongLastName"));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("123"));
        assertThrows(IllegalArgumentException.class, () -> c.setAddress(
            "This address is definitely way longer than thirty characters"));
    }
}
