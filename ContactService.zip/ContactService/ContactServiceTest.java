import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    private ContactService service;
    private Contact c1;

    @BeforeEach
    void setUp() {
        service = new ContactService();
        c1 = new Contact("001", "Alice", "Smith", "0123456789", "456 Elm St");
    }

    @Test
    void addContactStoresContact() {
        service.addContact(c1);
        // no exception = success
    }

    @Test
    void addDuplicateIdThrows() {
        service.addContact(c1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(c1));
    }

    @Test
    void deleteExistingContactRemovesIt() {
        service.addContact(c1);
        service.deleteContact("001");
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("001"));
    }

    @Test
    void deleteNonexistentThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("999"));
    }

    @Test
    void updateFirstNameSucceeds() {
        service.addContact(c1);
        service.updateFirstName("001", "Bob");
        assertEquals("Bob", c1.getFirstName());
    }

    @Test
    void updateFirstNameInvalidOrMissingThrows() {
        service.addContact(c1);
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("001", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("001", "NameIsTooLong"));
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("999", "Bob"));
    }

    @Test
    void updateLastNameSucceeds() {
        service.addContact(c1);
        service.updateLastName("001", "Jones");
        assertEquals("Jones", c1.getLastName());
    }

    @Test
    void updatePhoneSucceeds() {
        service.addContact(c1);
        service.updatePhone("001", "1234567890");
        assertEquals("1234567890", c1.getPhone());
    }

    @Test
    void updateAddressSucceeds() {
        service.addContact(c1);
        service.updateAddress("001", "789 Pine Ave");
        assertEquals("789 Pine Ave", c1.getAddress());
    }

    @Test
    void updateNonexistentContactThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("999", "Lee"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("999", "1234567890"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("999", "Somewhere"));
    }
}
