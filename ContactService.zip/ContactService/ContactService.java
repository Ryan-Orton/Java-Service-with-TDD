import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    /**
     * Adds a new contact. IDs must be unique.
     * @throws IllegalArgumentException if contact is null or ID already exists.
     */
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null.");
        }
        String id = contact.getContactId();
        if (contacts.containsKey(id)) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        contacts.put(id, contact);
    }

    /**
     * Deletes the contact with the given ID.
     * @throws IllegalArgumentException if no contact with that ID.
     */
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        contacts.remove(contactId);
    }

    /**
     * Updates the first name of the contact with the given ID.
     */
    public void updateFirstName(String contactId, String firstName) {
        getContactById(contactId).setFirstName(firstName);
    }

    /**
     * Updates the last name of the contact with the given ID.
     */
    public void updateLastName(String contactId, String lastName) {
        getContactById(contactId).setLastName(lastName);
    }

    /**
     * Updates the phone number of the contact with the given ID.
     */
    public void updatePhone(String contactId, String phone) {
        getContactById(contactId).setPhone(phone);
    }

    /**
     * Updates the address of the contact with the given ID.
     */
    public void updateAddress(String contactId, String address) {
        getContactById(contactId).setAddress(address);
    }

    // helper to fetch or fail
    private Contact getContactById(String contactId) {
        Contact c = contacts.get(contactId);
        if (c == null) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
        return c;
    }
}